import * as schParametros from "../schemas/parametros";
import { ParametrosInterface } from "./parametros.interface";
const TIPO_USB = 'USB';
const TIPO_SERIE = 'SERIE';
const TIPO_CLEARONE = 'CLEARONE';
const TIPO_3G = '3G';
const TIPO_ENTRADA = 'ENTRADA';
const TIPO_SALIDA = 'SALIDA';
const parametrosVacios = {
    _id: '',
    licencia: 0,
    codigoTienda: 0,
    database: '',
    nombreEmpresa: '',
    nombreTienda: '',
    tipoImpresora: TIPO_USB,
    tipoDatafono: TIPO_CLEARONE,
    impresoraCafeteria: 'NO',
    clearOneCliente: 0,
    clearOneTienda: 0,
    clearOneTpv: 0,
    botonesConPrecios: 'No',
    prohibirBuscarArticulos: 'No',
    ultimoTicket: -1

};

 export class ParametrosClase {
    private parametros: ParametrosInterface;

    getParametros(): Promise<ParametrosInterface> {
        return schParametros.getParams().then((infoParams) => {
            if (infoParams !== null) {
                return infoParams;
            } else {
                const resParams: ParametrosInterface = parametrosVacios;
                return resParams;
            }
        }).catch((err) => {
            console.log(err);
            return parametrosVacios;
        });
    }

    setParametros(params: ParametrosInterface) {
        this.parametros.licencia = params.licencia;
        this.parametros.tipoImpresora = params.tipoImpresora;
        this.parametros.tipoDatafono = params.tipoDatafono;
        this.parametros.impresoraCafeteria = params.impresoraCafeteria;
        this.parametros.ultimoTicket = params.ultimoTicket;
    }

    todoInstalado(): Promise<boolean> {
        return this.getParametros().then((parametros) => {
            if (parametros._id === '' || parametros.licencia === 0 || parametros.codigoTienda === 0) {
                return false;
            } else {
                return true;
            }
        });
    }

    checkParametrosOK(params: ParametrosInterface) {
        if (params.licencia > 0 && params.codigoTienda > 0 && params.database.length > 0 && params.nombreEmpresa.length > 0 && params.nombreTienda.length > 0 && params.tipoImpresora.length > 0 && params.tipoDatafono.length > 0) {
            return true;
        }
    }

    setCurrentIdTrabajador(idTrabajador: number): Promise<boolean> {
        return schParametros.updateCurrentTrabajador(idTrabajador).then((query) => {
            if (query) {
                return true;
            } else {
                return false;
            }
        });
    }
}

const parametros = new ParametrosClase();

export { parametros }