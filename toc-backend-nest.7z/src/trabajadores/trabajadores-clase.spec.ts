import { TrabajadoresClase } from './trabajadores-clase';

describe('TrabajadoresClase', () => {
  it('should be defined', () => {
    expect(new TrabajadoresClase()).toBeDefined();
  });
});
