import { Controller } from '@nestjs/common';

@Controller('fichajes')
export class FichajesController {}
