import { mongoose } from '../conexion/conexion';
import { ArticulosInterface } from '../articulos/articulos.interface';

var schemaArticulos = new mongoose.Schema({
    _id: Number,
    nombre: String,
    precioConIva: Number,
    precioBase: Number,
    tipoIva: Number,
    esSumable: Boolean,
    familia: String
});
var Articulos = mongoose.model('articulos', schemaArticulos);

export function insertarArticulos(data) {
    var devolver = new Promise((dev, rej)=>{
        Articulos.insertMany(data).then(()=>{
            dev(true);
        });
    });
    return devolver;
    // var devolver = new Promise((dev, rej)=>{
    //     Articulos.updateMany({}, data, {upsert: true}).then(()=>{
    //         dev(true);
    //     });
    // });
    // return devolver;
}

export function buscarArticulo(busqueda: string) {
    return Articulos.find({$or:[{"nombre": { '$regex': new RegExp(busqueda, 'i')}}]}, null, {lean: true, limit: 20});
}

export function getInfoArticulo(idArticulo: number): Promise<ArticulosInterface> {
    var devolver: Promise<ArticulosInterface> = new Promise((dev, rej) => {
        Articulos.findById(idArticulo).lean().then((infoArticulo) => {
            if(infoArticulo) {
                dev(infoArticulo);
            }
            else {
                rej("El artículo no existe");
            }
        });
    });
    return devolver;
}

export function getNombreArticulo(id) {
    var devolver = new Promise((dev, rej) => {
        Articulos.findById(id).lean().then((info: any) => {
            dev(info.nombre);
        });
    })
    return devolver;
}

export function getPrecio(id) {
    return Articulos.findById(id).lean();
}

export function getPrecios() {
    return Articulos.find({}, {_id: 0, nombre: 1, precioConIva: 1}).lean();
}

export function borrarArticulos() {
    return Articulos.deleteMany({});
}