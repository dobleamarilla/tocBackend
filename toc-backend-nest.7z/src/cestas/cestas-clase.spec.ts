import { cestas } from './cestas-clase';

describe('CestasClase', () => {
  it('should be defined', () => {
    expect(cestas).toBeDefined();
  });
});
