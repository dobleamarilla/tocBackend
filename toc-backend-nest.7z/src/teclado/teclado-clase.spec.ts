import { TecladoClase } from './teclado-clase';

describe('TecladoClase', () => {
  it('should be defined', () => {
    expect(new TecladoClase()).toBeDefined();
  });
});
