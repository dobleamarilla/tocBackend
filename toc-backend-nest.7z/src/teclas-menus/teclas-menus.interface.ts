export interface TeclasMenus {
    nomMenu: string
}
