import { ofertas } from './ofertas-clase';

describe('OfertasClase', () => {
  it('should be defined', () => {
    expect(ofertas).toBeDefined();
  });
});
