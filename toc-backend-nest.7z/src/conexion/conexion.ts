const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/tocgame', {
    useNewUrlParser: true, 
    useUnifiedTopology: true 
}).catch((err) => {
    console.log(err);
});

function cerrarConexion() {
    mongoose.connection.close();
}

export { mongoose, cerrarConexion };
