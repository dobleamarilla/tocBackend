import { Controller } from '@nestjs/common';

@Controller('trabajadores')
export class TrabajadoresController {}
