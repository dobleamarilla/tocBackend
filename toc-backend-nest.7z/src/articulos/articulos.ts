import * as schArticulos from "../schemas/articulos";
import * as schArticulosTarifaEspecial from "../schemas/articulosTarifaEspecial";
import { ArticulosInterface } from './articulos.interface';

export class Articulos {
    private tecladoTarifaEspecial: boolean;
    constructor() {
        this.tecladoTarifaEspecial = false;
    }

    /* Devuelve un articulo */
    async getInfoArticulo(idArticulo: number) {
        const vacio: ArticulosInterface = null;
        if(!this.tecladoTarifaEspecial) {
            const infoArticulo = await schArticulos.getInfoArticulo(idArticulo);
            if(infoArticulo) {
                return infoArticulo;
            } else {
                return vacio;
            }
        } else {
            const infoArticuloTarifaEspecial = await schArticulosTarifaEspecial.getInfoArticuloTarifaEspecial(idArticulo);
            if(infoArticuloTarifaEspecial) {
                return infoArticuloTarifaEspecial;
            } else {
                return vacio;
            }
        }
    }
}
const articulosInstance = new Articulos();
export { articulosInstance };