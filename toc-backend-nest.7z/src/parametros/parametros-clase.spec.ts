import { ParametrosClase } from './parametros-clase';

describe('ParametrosClase', () => {
  it('should be defined', () => {
    expect(new ParametrosClase()).toBeDefined();
  });
});
