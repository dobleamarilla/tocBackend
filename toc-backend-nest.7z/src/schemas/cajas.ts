import {mongoose} from '../conexion/conexion';
import { CajaInterface } from 'src/caja/caja-interface.interface';

var schemaCajas = new mongoose.Schema({
    _id: String, //siempre es 'CAJA'
    inicioTime: Number,
    finalTime: Number,
    idDependienta: Number,
    totalApertura: Number,
    totalCierre: Number,
    descuadre: Number,
    recaudado: Number,
    nClientes: Number,
    ultimoTicket: Number,
    calaixFetZ: Number,
    infoExtra: {
        cambioInicial: Number,
        cambioFinal: Number,
        totalSalidas: Number,
        totalEntradas: Number,
        totalEnEfectivo: Number,
        totalTarjeta: Number,
        totalDeuda: Number
    },
    primerTicket: Number,
    detalleApertura: [{
        _id: String,
        valor: Number,
        unidades: Number
    }],
    detalleCierre: [{
        _id: String,
        valor: Number,
        unidades: Number
    }],
    enviado: Boolean,
    enTransito: Boolean,
    totalDatafono3G: Number,
    totalClearOne: Number
});

var Cajas = mongoose.model('cajas', schemaCajas);

export function getInfoCaja(): Promise<CajaInterface> {
    return Cajas.findById("CAJA", function (err, kes) {
        if(err) {
            console.log(err, kes);
        }
    }).lean();

}
export function setInfoCaja(data: CajaInterface): Promise<any> {
    return Cajas.replaceOne({ _id: "CAJA" }, data, {upsert: true}, (err, result) => {
        return err;
    });
}