import { teclasMenus } from './teclas-menus';

describe('TeclasMenus', () => {
  it('should be defined', async () => {
    expect(teclasMenus).toBeDefined();
    const menu = await teclasMenus.clickMenu('101 Bebidas');
    expect(typeof menu[0].color).toEqual("number")
    expect(typeof menu[0].esSumable).toEqual("boolean")
    expect(typeof menu[0].idArticle).toEqual("number")
    expect(typeof menu[0].nomMenu).toEqual("string")
    expect(typeof menu[0].nombreArticulo).toEqual("string")
    expect(typeof menu[0].pos).toEqual("number")
  });
});
