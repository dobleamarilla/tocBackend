export class TecladoClase {}
