import { Controller, Post, Body } from '@nestjs/common';

@Controller('tickets')
export class TicketsController {

}
