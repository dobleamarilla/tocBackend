import * as schTrabajadores from "../schemas/trabajadores";
import { parametros } from "../parametros/parametros-clase";
import { TrabajadoresInterface, trabajadorVacio } from "./trabajadores.interface";

export class TrabajadoresClase {
    actualizarTrabajadores() {
        this.setStopNecesario(true);
        socket.emit('descargar-trabajadores', { licencia: this.parametros.licencia, database: this.parametros.database, codigoTienda: this.parametros.codigoTienda});
    }

    getCurrentTrabajador(): Promise<TrabajadoresInterface> {
        return parametros.getParametros().then((params) => {
            if (params != null) {
                return schTrabajadores.getTrabajadorPorId(params.idCurrentTrabajador);
            } else {
                // Controlar que está vacío = no hay current
                return trabajadorVacio;
            }
        });
    }

    setCurrentTrabajador(idTrabajador: number): Promise<boolean> {
        return parametros.setCurrentIdTrabajador(idTrabajador).then((resultado) => {
            if (resultado) {
                return true;
            } else {
                return false;
            }
        });
    }

    getTrabajadoresFichados() {
        return schTrabajadores.getTrabajadoresFichados();
    }

    ficharTrabajador(idTrabajador: number): Promise<boolean> {
        return schTrabajadores.ficharTrabajador(idTrabajador).then((res) => {
            if (res) {
                console.log("Trabajador fichado?");
                return true;
            } else {
                console.log("Error al fichar?");
                return true;
            }
        });
    }

    desficharTrabajador(idTrabajador: number): Promise<boolean> {
        return schTrabajadores.desficharTrabajador(idTrabajador).then((res) => {
            if (res) {
                console.log("Trabajador desfichado?");
                return true;
            } else {
                console.log("Error al desfichar?");
                return true;
            }
        });
    }

    getTrabajador(idTrabajador: number): Promise<TrabajadoresInterface> {
        return schTrabajadores.getTrabajadorPorId(idTrabajador);
    }
}

export const trabajadoresInstance = new TrabajadoresClase();