import * as schCajas from "../schemas/cajas";
import { CajaInterface, cajaVacia } from "./caja-interface.interface";

export class CajaClase {
    getInfoCaja(): Promise<CajaInterface> { //COMPROBADO CON NEST
        return schCajas.getInfoCaja();
    }

    cajaAbierta(): Promise<boolean> {
        return this.getInfoCaja().then((infoCaja) => {
            if (infoCaja === null) {
                return false;
            } else {
                return true;
            }
        }).catch((err) => {
            console.log(err);
            return false;
        });
    }

    abrirCaja(unaCaja: CajaInterface): Promise<boolean> {
        // Crear el documento con ID = "CAJA"
        return schCajas.setInfoCaja(unaCaja).then((error) => {
            if (error) {
                return false;
            } else {
                return true;
            }
        }).catch((err) => {
            console.log(err);
            return false;
        });
        
    }

    async cerrarCaja(total: number, detalleCierre, guardarInfoMonedas, totalDatafono3G: number, totalClearOne: number) { //Promise<boolean> {
        return this.cajaAbierta().then((estaAbierta) => {
            if (estaAbierta) {
                return this.getInfoCaja().then((cajaActual) => {
                    cajaActual.totalCierre = total;
                    cajaActual.detalleCierre = detalleCierre;
                    cajaActual.finalTime = Date.now();
                    cajaActual.idDependienta = this.getCurrentTrabajador()._id;
                    cajaActual.totalDatafono3G = totalDatafono3G;
                    cajaActual.totalClearOne = totalClearOne;
                    cajaActual = this.calcularDatosCaja(cajaActual);
            
                    var infoDeliveroo = ipcRenderer.sendSync('getDedudaDeliveroo', {inicio: cajaActual.inicioTime, final: cajaActual.finalTime});
                    var deudaDeliveroo = 0;
            
                    var infoGlovo = ipcRenderer.sendSync('getDedudaGlovo', {inicio: cajaActual.inicioTime, final: cajaActual.finalTime});
                    var deudaGlovo = 0;
            
                    var infoTkrs = ipcRenderer.sendSync('getTotalTkrs', {inicio: cajaActual.inicioTime, final: cajaActual.finalTime});
                    var totalTkrs = 0;
            
            
                    if(infoDeliveroo.length > 0){
                        deudaDeliveroo = infoDeliveroo[0].suma;
                    }
                    if(infoGlovo.length > 0){
                        deudaGlovo = infoGlovo[0].suma;
                    }
                    if(infoTkrs.length > 0){
                        totalTkrs = infoTkrs[0].suma;
                    }
                    let objEmail = {
                        caja: cajaActual,
                        nombreTienda: this.getParametros().nombreTienda,
                        nombreDependienta: this.getCurrentTrabajador().nombre,
                        arrayMovimientos: ipcRenderer.sendSync('get-rango-movimientos', {fechaInicio: cajaActual.inicioTime, fechaFinal: cajaActual.finalTime}),
                        deudaGlovo: deudaGlovo,
                        deudaDeliveroo: deudaDeliveroo,
                        totalTkrs: totalTkrs
                    }
            
                    ipcRenderer.send('guardarCajaSincro', cajaActual);
                    
                    ipcRenderer.send('enviar-email', objEmail);
                    ipcRenderer.send('set-monedas', guardarInfoMonedas);
                    this.borrarCaja()
                    vueCaja.cerrarModal();
                    this.iniciar();
                    //return false;
                }).catch((err) => {
                    console.log(err);
                    return false;
                });
            } else {
                return false;
            }
        }).catch((err) => {
            console.log(err);
            return false;
        });
    }

    calcularDatosCaja(unaCaja: CajaInterface): Promise<CajaInterface> {
        var arrayTicketsCaja: Ticket[] = ipcRenderer.sendSync('getTicketsIntervalo', unaCaja);
        var arrayMovimientos: Movimientos[] = ipcRenderer.sendSync('get-rango-movimientos', {fechaInicio: unaCaja.inicioTime, fechaFinal: unaCaja.finalTime});
        var totalTickets = 0;
        var nombreTrabajador = this.getCurrentTrabajador().nombre;
        var descuadre = 0;
        var nClientes = 0;

        if(arrayTicketsCaja.length > 0)
        {
            this.caja.primerTicket = arrayTicketsCaja[0]._id;
            this.caja.ultimoTicket = arrayTicketsCaja[arrayTicketsCaja.length-1]._id;
        }
        
        var nombreTienda = this.parametros.nombreTienda;
        var fechaInicio = this.caja.inicioTime;
        var totalTarjeta = 0;
        var totalEnEfectivo = 0;
        var cambioInicial = this.caja.totalApertura;
        var cambioFinal = this.caja.totalCierre;
        var totalSalidas = 0;
        var totalEntradas = 0;
        var recaudado = 0; //this.caja.totalCierre-this.caja.totalApertura + totalSalidas - totalEntradas;
        var totalDeuda = 0;
        for(let i = 0; i < arrayMovimientos.length; i++)
        {
            if(arrayMovimientos[i].tipo === TIPO_SALIDA)
            {
                if(arrayMovimientos[i].tipoExtra != 'CONSUMO_PERSONAL')
                {
                    totalSalidas += arrayMovimientos[i].valor;
                }                
            }
            else
            {
                if(arrayMovimientos[i].tipo === TIPO_ENTRADA)
                {
                    totalEntradas += arrayMovimientos[i].valor;
                }
            }
        }
        for(let i = 0; i < arrayTicketsCaja.length; i++)
        {
            nClientes++;
            totalTickets += arrayTicketsCaja[i].total;
            

            switch(arrayTicketsCaja[i].tipoPago){
                case "TARJETA": totalTarjeta += arrayTicketsCaja[i].total; break;
                case "EFECTIVO": 
                    recaudado += arrayTicketsCaja[i].total;
                    totalEnEfectivo += arrayTicketsCaja[i].total;
                    break;
                case "DEUDA": totalDeuda += arrayTicketsCaja[i].total; break;
                case "TICKET_RESTAURANT": 
                    recaudado += arrayTicketsCaja[i].total;
                    totalEnEfectivo += arrayTicketsCaja[i].total;
                    break;
            }

        }
        this.caja.calaixFetZ = totalTickets;
        this.caja.infoExtra.cambioFinal = cambioFinal;
        this.caja.infoExtra.cambioInicial = cambioInicial;
        this.caja.infoExtra.totalSalidas = totalSalidas;
        this.caja.infoExtra.totalEntradas = totalEntradas;
        this.caja.infoExtra.totalEnEfectivo = totalEnEfectivo;
        this.caja.infoExtra.totalTarjeta = totalTarjeta;
        this.caja.infoExtra.totalDeuda = totalDeuda;

        descuadre = cambioFinal-cambioInicial+totalSalidas-totalEntradas-totalTickets;
        recaudado = totalTickets + descuadre - totalTarjeta - totalDeuda;
        
        const objImpresion = {
            calaixFet: totalTickets,
            nombreTrabajador: nombreTrabajador,
            descuadre: descuadre,
            nClientes: nClientes,
            recaudado: recaudado,
            arrayMovimientos: arrayMovimientos,
            nombreTienda: nombreTienda,
            fechaInicio: fechaInicio,
            fechaFinal: this.caja.finalTime,
            totalSalidas: totalSalidas,
            totalEntradas: totalEntradas,
            cInicioCaja: cambioInicial,
            cFinalCaja: cambioFinal,
            impresora: this.parametros.tipoImpresora,
            totalTarjeta: totalTarjeta
        };

        vuePantallaCierre.setVariables(objImpresion);
        try
        {
            this.imprimirCierreCaja(objImpresion);
        }
        catch(err)
        {
            vueToast.abrir('error', 'Impresora no detectada');
            console.log(err);
        }
        
        unaCaja.descuadre = descuadre;
        unaCaja.nClientes = nClientes;
        unaCaja.recaudado = recaudado;

        return unaCaja;
    }
}

const caja = new CajaClase();

export { caja }