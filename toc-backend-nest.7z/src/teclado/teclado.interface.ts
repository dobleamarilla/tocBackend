export interface TecladoInterface {
    nomMenu: string,
    idArticle: number,
    nombreArticulo: string,
    pos: number,
    color: number,
    esSumable: boolean
}
