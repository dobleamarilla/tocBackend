import { Toc } from './toc';

describe('Toc', () => {
  it('should be defined', () => {
    expect(new Toc()).toBeDefined();
  });
});
