import { caja } from './caja';

describe('Caja', () => {
  it('should be defined', () => {
    expect(caja).toBeDefined();
  });
});
