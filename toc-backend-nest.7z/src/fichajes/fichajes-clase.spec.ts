import { FichajesClase } from './fichajes-clase';

describe('FichajesClase', () => {
  it('should be defined', () => {
    expect(new FichajesClase()).toBeDefined();
  });
});
