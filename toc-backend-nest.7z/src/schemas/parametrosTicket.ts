import {mongoose} from '../conexion/conexion';

var schemaParametrosTicket = new mongoose.Schema({
    nombreDato: String,
    valorDato: String
});
var ParametrosTicket = mongoose.model('parametros-ticket', schemaParametrosTicket);

export function insertarParametrosTicket(data)
{
    var devolver = new Promise((dev, rej)=>{
        ParametrosTicket.insertMany(data).then(()=>{
            dev(true);
        });
    });
    return devolver;
}
export function getParamsTicket()
{
    return ParametrosTicket.find({}, ((err, resultado)=>{
        if(err)
        {
            console.log(err);
        }
    })).lean();
}